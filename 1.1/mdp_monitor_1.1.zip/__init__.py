# MDP Idyllwild Incident Monitor App

"""MDP monitoring package - see monitorapp.py for more info"""

__version__ = "1.0"
